#include <iostream>
#include "Cola.h"
using namespace std;
int main(int argc, char* argv[]) {
    Cola colita;
    Nodo* inicio = NULL, * fin = NULL; //Punteros libres para el manejo de la cola
    int opc = 0, respuesta = 0;
    do {
        cout << "1. LA COLA ESTA VACIA?" << endl;
        cout << "2. ENCOLAR" << endl;
        cout << "3. DESENCOLAR" << endl;
        cout << "4. FINALIZAR" << endl;
        cout << "Opcion: "; cin >> opc;


        switch (opc) {
        case 1:
            if (inicio == NULL)
                cout << "La cola se encuentra vacia" << endl;
            else
                cout << "Existe elemento(s) dentro de la cola" << endl;
            break;
        case 2:
            colita.encolar(inicio, fin);
            break;
        case 3:
            colita.desencolar(inicio);
            break;

        }

    } while (opc != 4);


    return 0;
}
