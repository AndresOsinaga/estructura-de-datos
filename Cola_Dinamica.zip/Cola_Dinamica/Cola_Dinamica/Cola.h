#pragma once
#include "Nodo.h"
#include <iostream>
class Cola{
private:
	Nodo* inicio;
	Nodo* fin;
public:
	Cola();
	~Cola();
	void encolar(Nodo*& inicio, Nodo*& fin);
	void desencolar(Nodo*& inicio);
};

