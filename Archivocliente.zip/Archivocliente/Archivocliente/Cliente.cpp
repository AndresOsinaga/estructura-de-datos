#include "Cliente.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

Cliente::Cliente() {
	nombre = "";
	correo = " ";
	telefono = 0;
	edad = 0;
	genero = ' ';
	estado = ' ';
}
Cliente::Cliente(string name, int tel, string add, int age, char gener) {
	nombre = name;
	telefono = tel;
	correo = add;
	edad = age;
	genero = gener;
	estado = 'A';
}
string Cliente::getNombre() {
	return nombre;
}
string Cliente::get_correo() {
	return correo;
}
int Cliente::getTelefono() {
	return telefono;
}
int Cliente::getEdad() {
	return edad;
}
char Cliente::getgenero() {
	return genero;
}
char Cliente::getEstado() {
	return estado;
}
void Cliente::guardarArchivo(ofstream& fsalida) {
	fsalida.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
	fsalida.write(reinterpret_cast<char*>(&edad), sizeof(edad));
	fsalida.write(reinterpret_cast<char*>(&telefono), sizeof(telefono));
	fsalida.write(reinterpret_cast<char*>(&correo), sizeof(correo));
	fsalida.write(reinterpret_cast<char*>(&genero), sizeof(genero));
	fsalida.write(reinterpret_cast<char*>(&estado), sizeof(estado));
}
bool Cliente::leerArchivo(ifstream& fentrada){
	bool W = false;
	if (fentrada.is_open() == true) {
		fentrada.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		if (fentrada.eof() == false) {
			fentrada.read(reinterpret_cast<char*>(&edad), sizeof(edad));
			fentrada.read(reinterpret_cast<char*>(&genero), sizeof(genero));
			fentrada.read(reinterpret_cast<char*>(&estado), sizeof(estado));
			W = true;
		}
		else {
			//cout << endl << "Registro no existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return W;
}
bool Cliente::eliminar(fstream& fes, int nroReg) {
	bool W = false;
	if (fes.is_open() == true) {
		fes.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
		fes.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
		if (fes.eof() == false) {
			fes.read(reinterpret_cast<char*>(&edad), sizeof(edad));
			fes.read(reinterpret_cast<char*>(&genero), sizeof(genero));
			fes.read(reinterpret_cast<char*>(&estado), sizeof(estado));

			estado = 'E';
			fes.seekp(getTamBytesRegistro() * (nroReg - 1), ios::beg);
			fes.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
			fes.write(reinterpret_cast<char*>(&edad), sizeof(edad));
			fes.write(reinterpret_cast<char*>(&genero), sizeof(genero));
			fes.write(reinterpret_cast<char*>(&estado), sizeof(estado));
			W = true;
		}
		else {
			cout << endl << "Registro no existe";
		}
	}
	else {
		cout << endl << "Arhivo no existe";
	}
	return W;
}
bool Cliente::modificar(fstream& fes, int nroReg) {

}
bool Cliente::buscar(ifstream& fentrada, int nroReg) {

}